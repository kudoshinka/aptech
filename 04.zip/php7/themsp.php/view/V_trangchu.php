<!DOCTYPE html>
<html>
<head>
	<title></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
	<style>
  /* Make the image fully responsive */
  .carousel-inner img {
    width: 100%;
    height: 400px;
  }
  </style>
</head>
<body>


<!-- MENU -->
<nav class=" h1 text-center col-md-12 text-primary font-weight-bold ">
  <ul class="navbar-nav">
   
    <li class="nav-item">
      <a class="nav-link" href="?controller=add_product"><b>Thêm Sản Phẩm</b></a>
    </li>
   
  </ul>
  
</nav>
	
</body>
</html>