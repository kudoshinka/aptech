<?php 

	$product = $db->get('sanpham',array());
	require_once('./view/V_trangchu.php');
?>